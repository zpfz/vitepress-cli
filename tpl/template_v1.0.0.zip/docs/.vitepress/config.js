module.exports = {
	title: "VitePress-CLI",
	description: "A lightweight CLI for VitePress project.",
	// base: '/base/',
	// lang: 'en-US',
	head: [
    ["link", { rel: "icon", href: "/_assets/img/logo.png" }]
  ],
	themeConfig: {
		nav: getNavBar(),
		sidebar: {
			"/category/": getCategorySidebar(),
		},
		lastUpdated: "Last Updated",
		repo: "zpfz/vitepress-cli",
		editLinks: false,
		// algolia: {
		//   apiKey: 'your_api_key',
		//   indexName: 'index_name'
		// }
		// carbonAds: {
		//   carbon: 'your-carbon-key',
		//   custom: 'your-carbon-custom',
		//   placement: 'your-carbon-placement'
		// }
	},
};

function getCategorySidebar() {
	return [
		{
			children: [
				{ text: "Category", link: "/category/" },
				{ text: "Article1", link: "/category/article-1" },
				{ text: "Article2", link: "/category/article-2" },
			],
		},
	];
}
function getNavBar() {
	return [
		// Nav 1
		{
			text: "Home",
			link: "/",
		},
		// Nav 2
		{
			text: "Category",
			link: "/category/",
		},
	];
}
